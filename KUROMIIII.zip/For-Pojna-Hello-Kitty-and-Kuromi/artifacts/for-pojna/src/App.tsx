import { type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type Photo = { src: string; name: string; alt: string };
const photoModules = import.meta.glob('./photos/*.{png,jpg,jpeg,webp,avif}', {
  eager: true,
  query: '?url',
  import: 'default',
}) as Record<string, string>;

const photos: Photo[] = Object.entries(photoModules)
  .sort(([a], [b]) => a.localeCompare(b))
  .map(([path, src]) => {
    const filename = path.split('/').pop()?.replace(/\.[^.]+$/, '') ?? 'memory';
    const isLego = filename.toLowerCase().includes('lego');
    const isAquarium = filename.toLowerCase().includes('aquarium');
    return {
      src,
      name: isLego ? 'LEGO display' : isAquarium ? 'Aquarium' : filename.replace(/[-_]/g, ' '),
      alt: isLego
        ? 'Pojna smiling beside a large LEGO display'
        : isAquarium
          ? 'Pojna looking at the aquarium’s blue underwater displays'
          : `A memory: ${filename.replace(/[-_]/g, ' ')}`,
    };
  });

const stanzas = [
  `I hope you know what that says about you,
to have been hurt and still be gentle,
to have your heart handed back in pieces
and somehow still have room for others.`,
  `You have spent so long being strong for others,
remembering the little things they forget,
showing up when your own world feels heavy,
giving people a kindness they haven't earned yet.`,
  `You've fought your battles quietly,
lost things you were certain would stay,
watched people make their choices
and wondered what made them walk away.`,
  `But someone else's leaving
doesn't make you less of a person.
You were never made smaller
by a love that couldn't love you properly.`,
  `And please, don't spend your life
trying to become someone worth staying for.
You already are.
You were before,
and you will be long after.`,
  `I wish to give you kind of love you deserve,
that notices when your smile is a little forced,
that listens when you speak in half sentences,
that stays without making you feel like a burden.`,
  `The kind that doesn't leave you guessing,
doesn't make affection feel like a prize,
doesn't ask you to hide your softer parts
just to keep a place in someone's life.`,
  `You don't have to turn your pain into something beautiful.
You don't have to smile through every scar.
Some days, getting out of bed is enough.
Some days, you can let someone else be strong for you.`,
  `Because I think there's something quietly wonderful
about a heart that has every reason to close
and still reaches for another hand,
still remembers to include the lonely one,
still gives, even after learning what it costs.`,
  `But, Pojna , you deserve to receive, too.`,
  `You deserve friendships that feel like home,
a shoulder that doesn't need an explanation,
a place at the table without asking,
and love that doesn't leave you questioning your place in it.`,
  `And if you ever forget what you mean,
I'll tell you plainly,
without a poem, without a grand gesture,
just the truth, sitting beside you:`,
  `You are not hard to love.
You are not too much.
You are not the sum of who left you.`,
  `You are a whole person, still growing,
still learning to give yourself
the same tenderness you've given the world.`,
];

function BowMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 54 38" className="bow-mark">
      <path d="M26 18C17 3 3 4 5 15c1 7 10 8 21 4M28 18C37 3 51 4 49 15c-1 7-10 8-21 4" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" />
      <path d="M20 18c-3 7-5 12-7 16M34 18c3 7 5 12 7 16" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="27" cy="18" r="4.5" fill="currentColor" />
    </svg>
  );
}

function KittyMotif({ className = '' }: { className?: string }) {
  return (
    <svg aria-hidden="true" viewBox="0 0 72 70" className={className}>
      <path d="M15 31 10 7l20 12M43 19 63 7l-5 25" fill="#fffdf8" stroke="#392b38" strokeWidth="2.5" strokeLinejoin="round" />
      <path d="M14 31c0-12 10-19 22-19s22 7 22 19v11c0 13-10 21-22 21S14 55 14 42Z" fill="#fffdf8" stroke="#392b38" strokeWidth="2.5" />
      <ellipse cx="27" cy="40" rx="2.5" ry="3.5" fill="#392b38" />
      <ellipse cx="45" cy="40" rx="2.5" ry="3.5" fill="#392b38" />
      <ellipse cx="36" cy="47" rx="2.2" ry="1.6" fill="#d54d61" />
      <path d="M15 43 4 41m11 7L5 51m52-8 11-2m-11 7 10 3" stroke="#392b38" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M49 15c-7-2-8-8-4-10 4-3 7 1 8 4 2-3 5-6 8-3 4 4 0 9-8 10l-2 5Z" fill="#e4495d" stroke="#392b38" strokeWidth="1.7" strokeLinejoin="round" />
      <path d="M48 14 61 7" stroke="#ffc9ce" strokeWidth="1.2" />
    </svg>
  );
}

function KuromiMotif({ className = '' }: { className?: string }) {
  return (
    <svg aria-hidden="true" viewBox="0 0 72 70" className={className}>
      <path d="M19 23 11 4l22 10c2-1 4-1 6 0L61 4l-8 21" fill="#302936" stroke="#302936" strokeWidth="3" strokeLinejoin="round" />
      <path d="M17 26c2-10 10-15 19-15s17 5 19 15l4 13c3 12-7 23-23 23S10 51 13 39Z" fill="#8066a8" stroke="#302936" strokeWidth="2.5" />
      <path d="M20 35c0-8 7-14 16-14s16 6 16 14v10c0 9-7 15-16 15s-16-6-16-15Z" fill="#fffaf4" stroke="#302936" strokeWidth="2" />
      <path d="M27 39c2-3 5-3 7 0v6c-2 2-5 2-7 0Zm12 0c2-3 5-3 7 0v6c-2 2-5 2-7 0Z" fill="#302936" />
      <path d="M32 51c2-2 6-2 8 0l-4 3Z" fill="#d64c64" />
      <path d="M36 6c-2-3 0-5 3-4 3 1 3 4 0 5Z" fill="#d64c64" stroke="#302936" strokeWidth="1.3" />
      <path d="M32 14 22 9m18 5 11-5" stroke="#ae9ad0" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function GiftPage() {
  const [opening, setOpening] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [actionsVisible, setActionsVisible] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const openTimer = useRef<number | undefined>(undefined);
  const actionTimer = useRef<number | undefined>(undefined);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const priorFocus = useRef<HTMLElement | null>(null);
  const galleryRef = useRef<HTMLElement>(null);

  const openLetter = () => {
    if (opening || letterOpen) return;
    setOpening(true);
    openTimer.current = window.setTimeout(() => {
      setLetterOpen(true);
      setOpening(false);
      setActionsVisible(false);
      const revealDelay = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 100 : 5800;
      actionTimer.current = window.setTimeout(() => setActionsVisible(true), revealDelay);
    }, 880);
  };

  const closeLetter = () => {
    window.clearTimeout(actionTimer.current);
    setLetterOpen(false);
    setActionsVisible(false);
    setOpening(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showMemories = () => galleryRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  useEffect(() => () => {
    window.clearTimeout(openTimer.current);
    window.clearTimeout(actionTimer.current);
  }, []);

  useEffect(() => {
    if (lightboxIndex === null) return;
    closeButtonRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setLightboxIndex(null);
      if (event.key === 'ArrowRight') setLightboxIndex((i) => i === null ? null : (i + 1) % photos.length);
      if (event.key === 'ArrowLeft') setLightboxIndex((i) => i === null ? null : (i - 1 + photos.length) % photos.length);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [lightboxIndex]);

  useEffect(() => {
    if (lightboxIndex === null && priorFocus.current) {
      priorFocus.current.focus();
      priorFocus.current = null;
    }
  }, [lightboxIndex]);

  useEffect(() => {
    const targets = document.querySelectorAll<HTMLElement>('.photo-card');
    if (!('IntersectionObserver' in window)) {
      targets.forEach((target) => target.classList.add('visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14 });
    targets.forEach((target) => observer.observe(target));
    return () => observer.disconnect();
  }, [letterOpen]);

  return (
    <main className="gift-page">
      {!letterOpen && (
        <section className="opening" aria-label="A letter for Pojna">
          <div className="opening-inner">
            <h1 className="opening-title">For Pojna</h1>
            <div className="opening-mascots" aria-hidden="true">
              <span className="mascot-sticker kitty-sticker"><KittyMotif /></span>
              <span className="mascot-sticker kuromi-sticker"><KuromiMotif /></span>
            </div>
            <button
              type="button"
              className={`envelope-button${opening ? ' is-opening' : ''}`}
              onClick={openLetter}
              aria-label="Open the letter addressed to Pojna Pajama"
              aria-expanded={letterOpen}
              data-testid="envelope-open"
            >
              <div className="envelope" aria-hidden="true">
                <div className="env-back" />
                <div className="env-paper">
                </div>
                <div className="env-front" />
                <div className="env-pocket" />
                <div className="env-address">To: Pojna Pajama</div>
                <div className="env-flap" />
                <div className="seal"><KuromiMotif className="seal-mark" /></div>
              </div>
              <p className="tap-label">Tap to open</p>
            </button>
          </div>
        </section>
      )}

      {letterOpen && (
        <section className="letter-wrap" aria-label="Letter for Pojna">
          <article className="letter" data-testid="letter-content">
            <div className="poem" aria-label="Letter poem">
              {stanzas.map((stanza, index) => (
                <div
                  className={`stanza${index === stanzas.length - 1 ? ' stanza-last' : ''}`}
                  key={index}
                  style={{ '--stanza-index': index } as React.CSSProperties}
                  data-testid={`poem-stanza-${index + 1}`}
                >
                  {stanza.split('\n').map((line, lineIndex) => (
                    <p key={lineIndex}>{line || '\u00a0'}</p>
                  ))}
                </div>
              ))}
            </div>
            {actionsVisible && (
              <div className="letter-actions" data-testid="letter-actions">
                <button className="gift-button" type="button" onClick={closeLetter} data-testid="close-letter">
                  Close the letter
                </button>
                <button className="gift-button primary" type="button" onClick={showMemories} data-testid="see-memories">
                  See our memories
                </button>
              </div>
            )}
          </article>
        </section>
      )}

      <section className="gallery-section" ref={galleryRef} aria-labelledby="gallery-title" data-testid="photo-gallery">
        <div className="gallery-inner">
          <header className="gallery-heading">
            <div>
              <h2 id="gallery-title">See our memories</h2>
            </div>
            <div className="gallery-mascots" aria-hidden="true">
              <KittyMotif className="gallery-kitty" />
              <KuromiMotif className="gallery-kuromi" />
            </div>
          </header>
          {photos.length === 0 ? (
            <p className="empty-photos" data-testid="photos-empty">Photos coming soon</p>
          ) : (
            <div className="photo-grid">
              {photos.map((photo, index) => (
                <button
                  type="button"
                  key={photo.src}
                  className="photo-card"
                  style={{
                    '--tilt': `${index % 2 === 0 ? -2.1 : 1.8}deg`,
                    '--photo-delay': `${(index % 3) * 110}ms`,
                  } as React.CSSProperties}
                  onClick={(event) => {
                    priorFocus.current = event.currentTarget;
                    setLightboxIndex(index);
                  }}
                  aria-label={`View photo: ${photo.alt}`}
                  data-testid={`photo-card-${index}`}
                >
                  <img src={photo.src} alt={photo.alt} loading="lazy" />
                  <span className="photo-caption">{photo.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </section>
      {lightboxIndex !== null && photos[lightboxIndex] && (
        <div
          className="lightbox"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo ${lightboxIndex + 1} of ${photos.length}`}
          data-testid="photo-lightbox"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setLightboxIndex(null);
          }}
        >
          <button
            type="button"
            ref={closeButtonRef}
            className="lightbox-control lightbox-close"
            onClick={() => setLightboxIndex(null)}
            aria-label="Close photo"
            data-testid="lightbox-close"
          >×</button>
          {photos.length > 1 && (
            <button
              type="button"
              className="lightbox-control"
              onClick={() => setLightboxIndex((lightboxIndex - 1 + photos.length) % photos.length)}
              aria-label="Previous photo"
              data-testid="lightbox-previous"
            >‹</button>
          )}
          <figure>
            <img src={photos[lightboxIndex].src} alt={photos[lightboxIndex].alt} />
            <figcaption>{photos[lightboxIndex].name} · {lightboxIndex + 1} / {photos.length}</figcaption>
          </figure>
          {photos.length > 1 && (
            <button
              type="button"
              className="lightbox-control"
              onClick={() => setLightboxIndex((lightboxIndex + 1) % photos.length)}
              aria-label="Next photo"
              data-testid="lightbox-next"
            >›</button>
          )}
        </div>
      )}
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={GiftPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
